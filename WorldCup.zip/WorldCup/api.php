<?php
// api.php - نسخه کامل

// Display all errors for debugging purposes
ini_set('display_errors', 1);
error_reporting(E_ALL);

// 1. تنظیمات اولیه برای پاسخ‌دهی به صورت JSON
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight request for CORS from modern browsers
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// 2. اطلاعات اتصال به پایگاه داده
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "worldcup_db";

// 3. اتصال به پایگاه داده
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $e->getMessage()]);
    exit();
}

// 4. دریافت متد درخواست
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

// 5. مسیریابی درخواست‌ها
if ($method === 'GET') {
    switch ($action) {
        case 'get_tournaments':
            getTournaments($conn);
            break;
        default:
            http_response_code(400);
            echo json_encode(["error" => "Invalid action specified."]);
            break;
    }
} elseif ($method === 'POST') {
    // دریافت داده‌های POST
    $input = json_decode(file_get_contents('php://input'), true);
    
    switch ($action) {
        case 'save_tournament':
            saveTournament($conn, $input);
            break;
        case 'delete_tournament':
            deleteTournament($conn, $input);
            break;
        default:
            http_response_code(400);
            echo json_encode(["error" => "Invalid action specified."]);
            break;
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed."]);
}

// 6. تعریف توابع

function getTournaments($conn) {
    try {
        $stmt = $conn->prepare("SELECT id, creation_date, data FROM tournaments ORDER BY creation_date DESC");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $tournaments = [];
        foreach ($results as $row) {
            $data = json_decode($row['data'], true); // Decode the TEXT/JSON data
            if (json_last_error() === JSON_ERROR_NONE) {
                $tournaments[] = [
                    'id' => $row['id'],
                    'date' => $row['creation_date'],
                    'champion' => isset($data['champion']) ? $data['champion'] : null,
                    'data' => $data 
                ];
            }
        }
        echo json_encode($tournaments);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Failed to fetch tournaments: " . $e->getMessage()]);
    }
}

function saveTournament($conn, $data) {
    if (empty($data)) {
        http_response_code(400);
        echo json_encode(["error" => "No data received."]);
        return;
    }
    
    // اعتبارسنجی JSON
    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid JSON data provided. " . json_last_error_msg()]);
        return;
    }

    try {
        // ذخیره داده‌ها به صورت JSON
        $jsonData = json_encode($data, JSON_UNESCAPED_UNICODE);
        $stmt = $conn->prepare("INSERT INTO tournaments (data) VALUES (?)");
        
        if ($stmt->execute([$jsonData])) {
            http_response_code(201);
            echo json_encode([
                "message" => "Tournament saved successfully.", 
                "id" => $conn->lastInsertId(),
                "date" => date('Y-m-d H:i:s')
            ]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Failed to execute statement."]);
        }
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Failed to save tournament: " . $e->getMessage()]);
    }
}

function deleteTournament($conn, $data) {
    if (!isset($data['id']) || empty($data['id'])) {
        http_response_code(400);
        echo json_encode(["error" => "Tournament ID is required."]);
        return;
    }
    
    $id = intval($data['id']);
    
    try {
        $stmt = $conn->prepare("DELETE FROM tournaments WHERE id = ?");
        
        if ($stmt->execute([$id])) {
            $deletedCount = $stmt->rowCount();
            
            if ($deletedCount > 0) {
                http_response_code(200);
                echo json_encode([
                    "message" => "Tournament deleted successfully.",
                    "deleted" => $deletedCount
                ]);
            } else {
                http_response_code(404);
                echo json_encode(["error" => "Tournament not found."]);
            }
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Failed to execute delete statement."]);
        }
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Failed to delete tournament: " . $e->getMessage()]);
    }
}
?>